import 'package:flutter/material.dart';

const Color kBackgroud = Color(0xFFF5F5F5);
const Color kPrimaryColor = Color(0xFFFDBF30);
